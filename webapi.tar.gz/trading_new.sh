#!/bin/bash


if [ $# -lt 1 ]
then
        echo "Usage : start|stop|startlocally|startsecond|test|algo|localnomarket"
        exit
fi


case "$1" in
start)
	echo "Starting Exchange"
	cd ~/webapi

# WebAPI Gateway Start

# No FIX output Captured
#java -Dfix.core.debug=FIX_MESSAGE -jar fix-gateway-1.0-SNAPSHOT.jar -cfg config.yml &>/dev/null &
# disown


# Send FIX messages to log file

# Used for remote access. Update to proper config file before using

#java -Dfix.core.debug=FIX_MESSAGE -jar fix-gateway-1.0-SNAPSHOT.jar -cfg config.yml &>~/webapi/FIXLOG &



java -Dfix.core.debug=FIX_MESSAGE -jar fix-gateway-1.0-SNAPSHOT.jar --spring.config.location=./application-local.yml &>~/webapi/FIXLOG &

disown

sleep 10

# Start Fake Auth

java -jar fake-auth-1.0-SNAPSHOT.jar &>/dev/null &
disown

sleep 10

# Start WebAPI Client

cd ~/webapi/tradingWebApiClient


python trader_app.py config.yml 
;;

algo)


java -Dfix.core.debug=FIX_MESSAGE -jar fix-gateway-1.0-SNAPSHOT.jar --spring.config.location=./application-algokirk.yml &>~/webapi/FIXLOG &
	
sleep 10

# Start Fake Auth
java -jar fake-auth-1.0-SNAPSHOT.jar &>/dev/null &

sleep 10
#Start python app point to local install

cd ~/webapi/tradingWebApiClient
python3 trader_app.py config-local.yml

;;




stop)
      echo "Stopping processes"
      pkill -9 -f "fix-gateway"
      pkill -9 -f "fake"
      pkill -9 -f "trader_app.py"
      ;;
startlocally)

	
	
# Start Fake Auth
java --add-opens java.base/sun.nio.ch=ALL-UNNAMED -jar fake-auth-2.1.1-0-_2.1.1.jar &>~/webapi/fakeauth &
disown
sleep 1
	
	
	#  java -Dfix.core.debug=FIX_MESSAGE -jar fix-gateway-1.0-SNAPSHOT.jar -cfg config-local.yml &>~/webapi/FIXLOG &
#   java -Dfix.core.debug=FIX_MESSAGE -jar fix-gateway-1.0-SNAPSHOT-dec1.jar --spring.config.location=./application-local.yml &>~/webapi/FIXLOG &
#java --add-opens java.base/sun.nio.ch=ALL-UNNAMED -Dfix.core.debug=FIX_MESSAGE -jar  fix-gateway-2.1.1-0-_2.1.1.jar --spring.config.location=./application-local.yml &>~/webapi/FIXLOG &
java -Dfix.core.debug=FIX_MESSAGE -jar  fix-gateway-2.1.1-0-_2.1.1.jar --spring.config.location=./application-local.yml &>~/webapi/FIXLOG &


disown

sleep 30



# Start WebAPI Client

cd ~/webapi/tradingWebApiClient


/usr/bin/python3 trader_app.py config.yml 
;;

localnomarket)

java -Dfix.core.debug=FIX_MESSAGE --DPR_712_MARKET_ORDERS_ENABLED=false jar fix-gateway-1.0-SNAPSHOT.jar --spring.config.location=./application-local.yml &>~/webapi/FIXLOG &


# Start Fake Auth

java -jar fake-auth-1.0-SNAPSHOT.jar &>~/webapi/fakeauth &
disown

sleep 10

# Start WebAPI Client

cd ~/webapi/tradingWebApiClient


python3 trader_app.py config-local.yml
;;




startsecond)

#java -Dfix.core.debug=FIX_MESSAGE -Daeron.archive.control.channel='aeron:udp?endpoint=localhost:8011' -Daeron.archive.recording.events.channel='aeron:udp?control-mode=dynamic|control=localhost:8031' -Daeron.archive.control.response.channel='aeron:udp?endpoint=localhost:8021' -jar fix-gateway-2.1.1-0-_2.1.1.jar --spring.config.location=./application-local2.yml 

java -add-opens java.base/sun.nio.ch=ALL-UNNAMED -Dfix.core.debug=FIX_MESSAGE -Daeron.archive.control.channel='aeron:udp?endpoint=localhost:8011' -Daeron.archive.recording.events.channel='aeron:udp?control-mode=dynamic|control=localhost:8031' -Daeron.archive.control.response.channel='aeron:udp?endpoint=localhost:8021' -jar fix-gateway-2.1.1-0-_2.1.1.jar --spring.config.location=./application-local2.yml

#disown

cd ~/webapi/tradingWebApiClient

#python3 trader_app2.py config-local2.yml
;;

test)
#  java -Dfix.core.debug=FIX_MESSAGE -jar fix-gateway-1.0-SNAPSHOT.jar -cfg config-test.yml &>~/webapi/FIXLOG &
  java -Dfix.core.debug=FIX_MESSAGE -jar fix-gateway-1.0-SNAPSHOT.jar --spring.config.location=./application-tst.yml &>~/webapi/FIXLOG &
disown

sleep 10

# Start Fake Auth

java -jar fake-auth-1.0-SNAPSHOT.jar &>/dev/null &
disown

sleep 10

# Start WebAPI Client

cd ~/webapi/tradingWebApiClient


python trader_app.py config.yml
;;


esac

